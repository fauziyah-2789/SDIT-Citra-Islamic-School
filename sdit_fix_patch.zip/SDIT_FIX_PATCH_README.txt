SDIT Citra - PATCH for Landing + Admin Components (ready to extract)

What is included (place into your project's root, overwrite existing files if you want the new design):
- resources/views/components/layouts/guest.blade.php
- resources/views/components/layouts/app.blade.php
- resources/views/components/admin/navbar.blade.php
- resources/views/components/loading.blade.php
- resources/views/public/landing.blade.php

Steps to apply (Windows PowerShell example):
1. Backup your current views (recommended):
   mkdir backup_views
   cp -Re resources/views backup_views

2. Extract this ZIP into your project root (overwrite).
   # If you are using the extracted folder here, just copy files into project.

3. Install frontend deps & build:
   npm install
   # If 'vite' is not recognized, install dev deps:
   # npm i -D vite laravel-vite-plugin
   npm run dev   # or: npx vite

4. Clear caches and ensure storage link:
   composer dump-autoload
   php artisan view:clear
   php artisan route:clear
   php artisan cache:clear
   php artisan storage:link

5. Visit (local):
   php artisan serve
   Open http://127.0.0.1:8000/  and check landing page.
   Admin dashboard: /admin/dashboard (login required)

Notes & Checklist I suggest you verify after patch:
- Ensure PublicController@index returns required data: gurus, programs, ekstras, beritas, galeris, prestasies.
- Ensure routes for landing and public views are present (routes/web.php).
- Confirm images (images/logo.png, images/guru/*, images/berita/*, images/galeri/*) exist in public/images.
- If CSS doesn't apply, confirm app.css and app.js are compiled with Vite or switch to CDN Tailwind (guest layout uses CDN).
- For animations AOS: ensure AOS assets loaded (we included CDN link).

If anything breaks, paste the error here and I will help fix step-by-step.
