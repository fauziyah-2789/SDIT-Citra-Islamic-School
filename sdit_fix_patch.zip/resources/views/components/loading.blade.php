{{-- Global loading overlay --}}
<div id="global-loading" class="fixed inset-0 bg-black/30 z-50 hidden items-center justify-center">
  <div class="bg-white rounded-lg p-5 flex items-center gap-3 shadow">
    <div class="animate-spin rounded-full h-8 w-8 border-4 border-green-600 border-t-transparent"></div>
    <div class="text-sm text-gray-700">Memuat …</div>
  </div>
</div>
<script>
window.showLoading = ()=> document.getElementById('global-loading')?.classList.remove('hidden');
window.hideLoading = ()=> document.getElementById('global-loading')?.classList.add('hidden');
</script>
