{{-- Admin navbar: hamburger, dropdowns, search, notif, profile --}}
<nav class="flex items-center justify-between gap-4 py-3">
  <div class="flex items-center gap-4">
    <button id="hamburger-btn" class="md:hidden p-2 rounded hover:bg-gray-100">
      <svg class="w-6 h-6 text-green-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </button>

    <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-3">
      <img src="{{ asset('images/logo.png') }}" alt="logo" class="h-10 w-10 object-contain">
      <span class="font-bold text-xl text-green-800">{{ config('app.name') }}</span>
    </a>
  </div>

  <div class="flex-1 px-4 hidden md:flex items-center justify-center">
    <form action="{{ route('admin.search') }}" method="GET" class="w-full max-w-2xl">
      <div class="flex items-center shadow-sm rounded-full overflow-hidden">
        <input name="q" type="text" placeholder="Cari (siswa/guru/berita)..." class="w-full px-4 py-3 bg-white/80 focus:outline-none" />
        <button class="px-4 py-3 bg-gradient-to-r from-green-400 to-green-600 text-white rounded-r-full">Cari</button>
      </div>
    </form>
  </div>

  <div class="flex items-center gap-3">
    <div class="hidden md:flex items-center gap-1">
      <div class="relative group">
        <button class="px-3 py-2 rounded text-sm text-gray-700 hover:text-green-800">Manajemen ▾</button>
        <div class="absolute right-0 mt-2 hidden group-hover:block bg-white border rounded-lg shadow-lg min-w-[220px]">
          <a href="{{ route('admin.guru.index') }}" class="block px-4 py-2 hover:bg-gray-50">Guru</a>
          <a href="{{ route('admin.siswa.index') }}" class="block px-4 py-2 hover:bg-gray-50">Siswa</a>
          <a href="{{ route('admin.kelas.index') }}" class="block px-4 py-2 hover:bg-gray-50">Kelas</a>
          <a href="{{ route('admin.mapel.index') }}" class="block px-4 py-2 hover:bg-gray-50">Mapel</a>
        </div>
      </div>

      <div class="relative group">
        <button class="px-3 py-2 rounded text-sm text-gray-700 hover:text-green-800">Konten ▾</button>
        <div class="absolute right-0 mt-2 hidden group-hover:block bg-white border rounded-lg shadow-lg min-w-[220px]">
          <a href="{{ route('admin.berita.index') }}" class="block px-4 py-2 hover:bg-gray-50">Berita</a>
          <a href="{{ route('admin.galeri.index') }}" class="block px-4 py-2 hover:bg-gray-50">Galeri</a>
          <a href="{{ route('admin.prestasi.index') }}" class="block px-4 py-2 hover:bg-gray-50">Prestasi</a>
          <a href="{{ route('admin.ekstrakurikuler.index') }}" class="block px-4 py-2 hover:bg-gray-50">Ekstrakurikuler</a>
        </div>
      </div>

      <div class="relative group">
        <button class="px-3 py-2 rounded text-sm text-gray-700 hover:text-green-800">Laporan ▾</button>
        <div class="absolute right-0 mt-2 hidden group-hover:block bg-white border rounded-lg shadow-lg min-w-[220px]">
          <a href="#" class="block px-4 py-2 hover:bg-gray-50">Laporan PDF</a>
        </div>
      </div>

      <div class="relative group">
        <button class="px-3 py-2 rounded text-sm text-gray-700 hover:text-green-800">Profil ▾</button>
        <div class="absolute right-0 mt-2 hidden group-hover:block bg-white border rounded-lg shadow-lg min-w-[220px]">
          <a href="{{ route('admin.profil.show') }}" class="block px-4 py-2 hover:bg-gray-50">Profil Sekolah</a>
          <a href="{{ route('admin.users.index') }}" class="block px-4 py-2 hover:bg-gray-50">Users</a>
        </div>
      </div>
    </div>

    <button title="Notifikasi" class="p-2 rounded-full hover:bg-gray-100">
      <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a6 6 0 00-6 6v3H3v1h14v-1h-1V8a6 6 0 00-6-6z"/></svg>
    </button>

    <div class="relative">
      <button id="profile-btn" class="flex items-center gap-2 rounded px-2 py-1 hover:bg-gray-100">
        <img src="{{ asset('images/avatar.png') }}" alt="avatar" class="w-9 h-9 rounded-full object-cover">
        <span class="hidden md:inline text-sm text-gray-700">{{ Auth::user()->name ?? 'Admin' }}</span>
      </button>

      <div id="profile-menu" class="hidden absolute right-0 mt-2 bg-white border rounded shadow-md text-sm">
        <a href="{{ route('profile.edit') }}" class="block px-4 py-2 hover:bg-gray-50">Profil</a>
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button class="w-full text-left px-4 py-2 hover:bg-gray-50">Logout</button>
        </form>
      </div>
    </div>
  </div>

  <div id="mobile-offcanvas" class="fixed inset-y-0 left-0 z-50 w-72 transform -translate-x-full transition-transform bg-white shadow-lg md:hidden">
    <div class="p-4 border-b flex items-center justify-between">
      <div class="flex items-center gap-2">
        <img src="{{ asset('images/logo.png') }}" alt="logo" class="h-8 w-8">
        <span class="font-semibold text-green-700">{{ config('app.name') }}</span>
      </div>
      <button id="mobile-close" class="p-1 rounded hover:bg-gray-100">×</button>
    </div>

    <div class="p-4">
      <a href="{{ route('admin.dashboard') }}" class="block px-3 py-2 rounded hover:bg-gray-50">Dashboard</a>
      <details class="group">
        <summary class="px-3 py-2 rounded hover:bg-gray-50 cursor-pointer">Manajemen</summary>
        <div class="pl-4 mt-2">
          <a href="{{ route('admin.guru.index') }}" class="block px-3 py-2 rounded hover:bg-gray-50">Guru</a>
          <a href="{{ route('admin.siswa.index') }}" class="block px-3 py-2 rounded hover:bg-gray-50">Siswa</a>
        </div>
      </details>

      <details class="group mt-2">
        <summary class="px-3 py-2 rounded hover:bg-gray-50 cursor-pointer">Konten</summary>
        <div class="pl-4 mt-2">
          <a href="{{ route('admin.berita.index') }}" class="block px-3 py-2 rounded hover:bg-gray-50">Berita</a>
          <a href="{{ route('admin.galeri.index') }}" class="block px-3 py-2 rounded hover:bg-gray-50">Galeri</a>
        </div>
      </details>

      <a href="{{ route('profile.edit') }}" class="block mt-3 px-3 py-2 rounded hover:bg-gray-50">Profil</a>
      <form method="POST" action="{{ route('logout') }}" class="mt-3">@csrf <button class="w-full text-left px-3 py-2 rounded hover:bg-gray-50">Logout</button></form>
    </div>
  </div>

<script>
document.addEventListener('click', function(e){
  if(e.target.closest('#profile-btn')) {
    document.getElementById('profile-menu').classList.toggle('hidden');
  } else {
    const pm = document.getElementById('profile-menu'); if(pm && !pm.classList.contains('hidden') && !e.target.closest('#profile-menu')) pm.classList.add('hidden');
  }

  if(e.target.closest('#hamburger-btn')) {
    document.getElementById('mobile-offcanvas').classList.remove('-translate-x-full');
  }
  if(e.target.closest('#mobile-close')) {
    document.getElementById('mobile-offcanvas').classList.add('-translate-x-full');
  }
});
</script>
