{{-- Admin/app layout (no sidebar) --}}
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{{ $title ?? config('app.name') }}</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="bg-gray-50 text-gray-800 antialiased">
  @includeIf('components.loading')
  <div class="min-h-screen flex flex-col">
    <header class="bg-white/60 backdrop-blur sticky top-0 z-40 shadow-sm">
      <div class="max-w-7xl mx-auto px-4">
        {{ $nav ?? '' }}
      </div>
    </header>

    <main class="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
      {{ $header ?? '' }}
      <div class="mt-4">
        {{ $slot }}
      </div>
    </main>

    <footer class="bg-white/70 border-t py-4">
      <div class="max-w-7xl mx-auto px-4 text-sm text-gray-500">
        &copy; {{ date('Y') }} {{ config('app.name') }}
      </div>
    </footer>
  </div>

  {{ $scripts ?? '' }}
</body>
</html>
